

								,-
                               //        
                              /:      ,
                             ;.(     //
                   |   ,     /`|    //
                   |\  |\    |,|   //
                |  (\  (\    |`|   |(
                (\  \\  \\   |,|   ;|
            .   ||   \\  \\  |`(   ;( 
            \\   \\  \\  \\  |.\\  ((                              
             \\   \\  \\  \\  \\ \;/:\                 
               \\  \\  \'. \\_,\\ /\""-._                
                \\  \\  \ \-"   \/ `;._ ".
               ___\\-\\-" \ \_  /,  |_ "._\
         _,--""___ \ \,_   "-_"- |".|(._ ".".-.
     _,-"_,--"""__ ) "."-_    "--\ \"("o\_\ "- ". 
   ,",-""" _.-'''_-"   "-_"-.__   \ \_\_//\)__"\_)					___________.__               .____               .__        __  .__                         _____                                     
 ,"    ',-'  ,-""   7"  _ "-.._""_>\__`""'"__ ""``-._				\__    ___/|  |__   ____     |    |    _______  _|__|____ _/  |_|  |__ _____    ____       /  _  \_______  _____   ___________ ___.__.
        ;  ," ,-",'/` ,":\.    `   `  `"""___`""-._  ".   )			  |    |   |  |  \_/ __ \    |    |  _/ __ \  \/ /  \__  \\   __\  |  \\__  \  /    \     /  /_\  \_  __ \/     \ /  _ \_  __ <   |  |
        ;,"_," ,' /`,"}}::\\         `... \____''' "\  '.|\			  |    |   |   Y  \  ___/    |    |__\  ___/\   /|  |/ __ \|  | |   Y  \/ __ \|   |  \   /    |    \  | \/  Y Y  (  <_> )  | \/\___  |
       ,","   :  /`/{{)/:::"\__,---._    \  \_____'''\    \			  |____|   |___|  /\___  >   |_______ \___  >\_/ |__(____  /__| |___|  (____  /___|  /   \____|__  /__|  |__|_|  /\____/|__|   / ____|
      , ,"_  ;  /`/ ///::::::::' ,-"-\    \__   \____''\ \ \						\/     \/            \/   \/             \/          \/     \/     \/            \/            \/              \/     
     ,,"   `;| ";; /}}/::'``':::(._``."-.__  """--    '_\ \ \										____              ___________                           .__                                       
    ('       ;// / {;;:'`````':; /`._."""  ""-.._ `"-. " (   )									   /  _ \             \_   _____/ _____ ______   ___________|__|__ __  _____                          
    /         )(/ <";"'``   ``/ /_.(             "_  "-_"\`);									   >  _ </\            |    __)_ /     \\____ \ /  _ \_  __ \  |  |  \/     \                         
    /         )(/ <";"'``   ``/ /_.(             "_  "-_"\`);									  /  <_\ \/            |        \  Y Y  \  |_> >  <_> )  | \/  |  |  /  Y Y  \                        
              (/ <";"``     `/ /`,(                "._ _".\; 									  \_____\ \           /_______  /__|_|  /   __/ \____/|__|  |__|____/|__|_|  /                        
               |<";"`   ``  / /"-"                    "  												 \/                   \/      \/|__|                               \/                         
               <";"` ``    / /__,;
																														Mod Created & Compiled by: XxHyde840xX


===========================================================================================================================================================================================================
THE LEVIATHAN ARMORY & EMPORIUM - v1.2FINAL - Shipment One - For v0.47.04 - DFHack_r2
===========================================================================================================================================================================================================

Download Location: https://dffd.bay12games.com/file.php?id=15182

Installation Instructions: Before you install the mod, please ensure that you have selected the graphics pack you wish to use beforehand. Then,
						   simply copy both the "hack" and "raw" folders from my mod into your Dwarf Fortress folder. That's it! You're all done! 
						   Please remember to make a copy of your game files in case you would like to revert to "vanilla" Dwarf Fortress.
						   Some tweaks require additional steps. Please see the Table of Contents for instructions if applicable.
						   Please keep this README on hand for future reference.
						   
						   Now, get out there and STRIKE THE EARTH!

===========================================================================================================================================================================================================

=========================================
WHAT IS THIS MOD?
=========================================		
				   
This is the first in a series of planned shipments from The Leviathan Armory & Emporium, now menacing with spikes of revisions! Shipment One
contains a variety of weapons, armor, shields, reactions, tweaks, "fixes," and other odds and ends. I will be building on this project with
additional shipments coming in the future. To see what's going on with the mod and any upcoming content, make suggestions, or get involved with
the project, please check out the Bay 12 Forums thread: http://www.bay12forums.com/smf/index.php?topic=177136.0 - Any constructive feedback is
always appreciated, I hope to improve and keep generating new content for the community.

The weapons and armor have not received extensive testing, however, I have based their tokens on several well known weapons and armor packs,
and have used the stock object raws as a baseline. While intended for use by the dwarven race, there is no reason why they can't be utilized
elsewhere. Unfortunately that is beyond the scope of The Leviathan Armory & Emporium at this current time. If there are any oddities in their
behavior or performance, as well as any changes, improvements, tweaks, or suggestions you may have, please get at me on the Bay 12 Forums, or
on Discord.

------------------------------------------------------------------------------------------------------------------------------------------------
I will always endeavor to ensure that my content is safe, and as compatible and user-friendly as possible, however;

*Please remember to backup any relevant files and folders before making edits and alterations to the game files.*

*****Once again, please remember to backup any relevant files and folders before making edits and alterations to the game files.*****
------------------------------------------------------------------------------------------------------------------------------------------------
			  
=========================================
VERSION/REVISION NOTES & CHANGELOG
=========================================

8/25/2020

v1.0 - Mod created and uploaded to DFFD.

v1.1 - Editing for grammar, punctuation, spelling, and formatting
	 - Fixed an error for the "training paw." It shows up in game now.
	 - Reuploaded to DFFD.
	 - Cleaned up DFFD/BAY12 posts and updated the README with version/revision notes.
	 
9/DD/2020

v1.2 - Testing for balance.
	 - Inappropriate [TRAINABLE] tokens for common domestic animals replaced. No more hunting donkeys and such. T'was a silly mistake.
	 - Bhuj and Long-Hafted Blade added to weapons list for Asin. Also added Stilleto after a bit of research.
	 - Various non-critical erros fixed here and there.
	 - Various edits to weapons/armor and inclusion of [ADJECTIVE] tokens for clarity.
	 - Added table of contents to the README.
	 - Modified mount_dwarf.lua script to include description.
	 - Fixed "Burn Vermin Remains" reaction to run from Wood Furnace as intended.
	 - Added ASCII-art title and reformatted the README layout.
	 - Added max-wave.lua scrpt.
	 - Added working keyboard shortcuts and in game descriptions for the custom reactions.
	 - Discovered and fixed an error with the rock bin reaction. It shows up in game now.
	 - Added "Quilted Cloth" variant of Gambeson for clothing, and armor testing purposes.
	 - Several "birds-of-prey" given the [DIVE_HUNTS_VERMIN] and [TRAINABLE_HUNTING] tokens.
	 - Reuploaded to DFFD for testing and finalization.

=========================================
REFERENCE ASSETS, CREDITS, & THANKS
=========================================

- Lucelle Weapons and Armor by: lucelle (DFFD-reference)
	- Link: https://dffd.bay12games.com/file.php?id=7097

- Stal's Armory Pack by: Stalhansch (DFFD-reference)
	- Link: https://dffd.bay12games.com/file.php?id=9539

- Rock Bins and Beds by: unknowncross (DFFD-reference)
	- Link: https://dffd.bay12games.com/file.php?id=10401

- Cacame Engravings by: Shima (DF-Wiki)
	- Link: https://dwarffortresswiki.org/index.php/Cacame_Awemedinade#Engraving_and_decorations

- Theplahunter's Armory by: Theplahunter (Discord)
	- Big thanks to the guy who took the time to answer a complete stranger about brigandines, gambesons, and halberds!	;)
	  Also, big thanks for the resources from your Armory.

- Fleeting Frames and FantasticFwoosh (Discord)
	- You guys are an endless font of knowledge and inspiration, and you have a knack for being around to answer questions and clarify. Kudos.

- Warmist for the original mount script for DFHack
	- Fanfloosh for the update.
		- Rumrusher for the script-smithing to 47.04_r2 compatibility, and for showing me that a gorlak can indeed mount an owl. XD
	
- TomiTapio, Author of OldGenesis (Bay 12 Forums)
	- For wiping out an entire list of questions in regards to modding in rock bins and beds, I salute you good sir. o7
	
- PatrikLundell for the librarian.lua, regionmanipulator.lua, and biomemanipulator.lua scripts.
	- Keep up the awesome work Patrik!

- Ralpha, Author of DF Storyteller (Discord)
	- Thanks for both DF Storyteller, and for inspiring me to include even MOAR shields as well as some rapiers and scimitars. :D
	
- Asin (Bay 12 Forums)
	- Fifty dorf-bucks and custom weapons in the form of a Bhuj, Long-Hafted Blade, and Stiletto have been included as promised for figuring out the
	  easter-egg reference to Final Fantasy VII. Way to go man!

- Loci (DF-Wiki) for the modified max-wave.lua script, enabling me to finally save some sanity. No more 50+ migrant waves, thank Armok!
	- Fleeting Frames for his contribution to the script!
	
- PeridexisErrant for the awesome LNP. Thanks for saving all us Lazy Newbs time, hassle, our hair, and our sanity.
	
- Last but certainly not least, Tarn "ToadyOne" Adams, and Zach "ThreeToe" Adams. Thank you for all the tireless, incredible work on Dwarf Fortress! 
	
  This mod is free to use, distribute, alter, include, or shred at your discretion,
  provided that you give a quick shout out to the author of this mod, and to the
  mod-authors and content creators who made this shipment possible.

  Welcome to The Leviathan Armory & Emporium - Shipment One
  
	- XxHyde840xX

=========================================
TABLE OF CONTENTS			  
=========================================

To help find what you're looking for, copy/paste the {bracketed} section, and then use the Ctrl+F function.

--------------------------------
I) Fixes, Changes, and Tweaks
--------------------------------
 
	(1) - {MEAD} - A fix for the unobtainable bumblebee mead/honey/wax issue.
	
	(2) - {PIXI} - A quick tweak to make fairies and pixies trappable.
	
	(3) - {ANIM} - Over 200 animals altered to enable pet availability, mounting, war-training, and/or hunting-training where appropriate.
	
	(4) - {RIDE} - Warmist's mount_dwarf.lua script (Rumrusher's Fork) enabling fortress mode mounts. Mount a Bear! Mount a Gorlak! Mount your Friends!?

--------------------------------
II) Extra DFHack Scripts
--------------------------------

	(1) - {BIOM} - PatrikLundell's biomemanipulator.lua script for tinkering with embark sites.
	
	(2) - {REGN} - PatrikLundell's regionmanipulator.lua script for tinkering with embark sites.
	
	(3) - {LIBR} - PatrikLundell's librarian.lua script for checking out the contents of your books in fortress mode.
	
	(4) - {WAVE} - Loci's max-wave.lua script (Fleeting Frames Fork) for dynamically limiting the ammount of migrants.
				   *YOU SHOULD TWEAK THIS ACCORDING TO YOUR PREFERENCES. REQUIRES SOME QUICK SETUP.*

--------------------------------
III) Elf-King Cacame Awemedinade
--------------------------------
 
	(1) - {CACA} - Engravings and decorations of everybody's favorite Elf-King.

--------------------------------
IV) Custom Reactions
--------------------------------
 
	(1) - {RBIN} - Craftable rock bins. Can be crafted in adventure mode.
	
	(2) - {RBED} - Craftable rock beds. Can be crafted in adventure mode.
	
	(3) - {VBRN} - Turn vermin remains into potash. Can be used in adventure mode.

--------------------------------
V) Custom Weapons - Swords
--------------------------------
 
	(1) - {WS01} - The Bastard Sword
	
	(2) - {WS02} - The Rapier
	
	(3) - {WS03} - The Flamberge
	
	(4) - {WS04} - The Estoc
	
	(5) - {WS05} - The Kampilan
	
	(6) - {WS06} - The Backsword
	
	(7) - {WS07} - The Nimcha
	
	(8) - {WS08} - The Shotel
	
	(9) - {WS09} - The Okab-Tarmid aka "The Buster Sword"
	
   (10) - {WS10} - The Unâl-Dastot aka "The Hardedge"
   
   (11) - {WS11} - The Long-Hafted Blade
   
--------------------------------
VI) Custom Weapons - Daggers
--------------------------------
 
	(1) - {WD01} - The Waveback Seax
	
	(2) - {WD02} - The Main-Gauche
	
	(3) - {WD03} - The Stiletto
	
--------------------------------
VII) Custom Weapons - Axes
--------------------------------
 
	(1) - {WA01} - The Goosewing Great-Axe
	
--------------------------------
VIII) Custom Weapons - Spears
--------------------------------
 
	(1) - {WE01} - The Hewing-Spear
	
	(2) - {WE02} - The Bhuj
	
--------------------------------
IX) Custom Weapons - Pikes
--------------------------------
 
	(1) - {WP01} - The Bearded Halberd
	
--------------------------------
X) Custom Weapons - Hammers
--------------------------------

	(1) - {WH01} - The Dwarven Maul
	
--------------------------------
XI) Custom Weapons - Maces
--------------------------------
 
	(1) - {WM01} - The Orgal's Paw	
	
--------------------------------
XII) Custom Weapons - Whips
--------------------------------
 
	(1) - {WW01} - The Dragon's Tail
	
--------------------------------
XIII) Custom Weapons - Training
--------------------------------
 
	(1) - {WT01} - The Training Halberd
	
	(2) - {WT02} - The Training Paw
	
	(3) - {WT03} - The Training Whip
	
	(4) - {WT04} - The Training Dagger

--------------------------------
XIV) Custom Weapons - Ranged
--------------------------------
 
	(1) - {WR01} - The Recurve Siege-Bow
	
	(2) - {WR02} - The Bayonetted Crossbow

--------------------------------
XV) Custom Weapons - Ammo
--------------------------------
 
	(1) - {WO01} -  The Bodkin Arrow
	
	(2) - {WO02} -  The Broadhead Quarrel
	
--------------------------------
XVI) Custom Armor - Chest
--------------------------------

	(1) - {AC01} - The Thick Gambeson
	
	(2) - {AC02} - The Quilted Gambeson

	(3) - {AC03} - The Brigandine

	(4) - {AC04} - The Mail Hauberk
	
--------------------------------
XVII) Custom Armor - Shields
--------------------------------

	(1) - {AS01} - The Targe
	
	(2) - {AS02} - The Target Shield

	(3) - {AS03} - The Aspis

	(4) - {AS04} - The Scutum
	
	(5) - {AS05} - The Wankel Shield
	
	(6) - {AS06} - The Square Shield

	(7) - {AS07} - The Heater Shield

	(8) - {AS08} - The Kite Shield

	(9) - {AS09} - The Coffin Shield
	
   (10) - {AS10} - The Teardrop Shield

   (11) - {AS11} - The Tower Shield

--------------------------------
XVIIV) Tokens for Entities
--------------------------------

	(1) - {ENTT} - entity_default.txt tokens
	
===========================================================================================================================================================================================================	

=======
{MEAD}
=======

creature_insects.txt
reaction_other.txt

--------------------------------------------------
Bumblebee Mead Fix + Honey & Wax from Bumblebees.
--------------------------------------------------

v47.04 - Courtesy of XxHyde840xX

For the purposes of this mod, the reaction has been replaced with my edited version. If you'd like to tweak an
existing save, or use this as a resource, a quick rundown of how I've done this can be found below.

	[ARTIFICIAL_HIVEABLE] token added to bumblebees in creature_insects.txt

The addition above should enable harvesting of both wax and honey, and the brewing of bumblebee mead.

	[REAGENT:honey:150:LIQUID_MISC:NONE:CREATURE_MAT:HONEY_BEE:HONEY] changed to
	[REAGENT:honey:150:LIQUID_MISC:NONE:NONE:NONE] in reaction_other.txt

[REACTION:MAKE_MEAD]
	[NAME:make mead]
	[BUILDING:STILL:CUSTOM_M]
	[REAGENT:honey:150:LIQUID_MISC:NONE:NONE:NONE]
		[UNROTTEN]
		[HAS_MATERIAL_REACTION_PRODUCT:DRINK_MAT]
	[REAGENT:honey container:1:NONE:NONE:NONE:NONE]
		[CONTAINS:honey]
		[PRESERVE_REAGENT]
		[DOES_NOT_DETERMINE_PRODUCT_AMOUNT]
	[REAGENT:barrel/pot:1:NONE:NONE:NONE:NONE]
		[EMPTY]
		[FOOD_STORAGE_CONTAINER] barrel or any non-absorbing tool with FOOD_STORAGE
		[PRESERVE_REAGENT]
		[DOES_NOT_DETERMINE_PRODUCT_AMOUNT]
	[PRODUCT:100:5:DRINK:NONE:GET_MATERIAL_FROM_REAGENT:honey:DRINK_MAT]
		[PRODUCT_TO_CONTAINER:barrel/pot]
		[PRODUCT_DIMENSION:150]
	[SKILL:BREWING]
	
	"[REAGENT:honey:150:LIQUID_MISC:NONE:CREATURE_MAT:HONEY_BEE:HONEY]" changed to
	"[REAGENT:honey:150:LIQUID_MISC:NONE:NONE:NONE]" in reaction_other.txt

This should work on an existing savefile, since I haven't added new reactions to the entity, just changed one.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{PIXI}
=======

creature_standard.txt

Ahh, the random tweak to enable trappable fairies and pixies. I did this as an experiment to see if I could get one to
live inside of a dwarves beard as a pet. Let me know if you manage to make it happen!

All I've done here is remove the [VERMIN_NOTRAP] token from both pixies and fairies in the creature_standard.txt file.

Then, I went and added the [PET_EXOTIC] token to both.

Again, as I've only changed an existing creature token, this should work on an existing savefile.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{ANIM}
=======


Over 200 animals in the base game have been altered to enable war-training, hunting-training, or have been modified to be mountable
as well. I have tried to ensure that the [MOUNT], [MOUNT_EXOTIC] [TRAINABLE], [TRAINABLE_WAR], and [TRAINABLE_HUNTING] tokens are
not inappropriately applied. In addition, I have added either the [PET] or [PET_EXOTIC] token to a couple animals, several are now
available as domesticated animals on embark as a result of the changes, and siegers may show up with some new mounts. I have also
given a few birds the [DIVE_HUNTS_VERMIN] and [TRAINABLE_HUNTING] tokens where I felt it was fitting but they are not listed below.
Mainly intended to spice up fortress mode when used with the included mount_dwarf.lua script. All changes to these raws are denoted
by *XxHyde840xX* appearing at the end in their respective .txt files. The list of animals changed is as follows in no particular order.
You can Ctrl+F if you need to search up a specific animal from the list.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

- Giant Toad						- Giant Wren						- Giant Snail						- Giant Roach		
- Giant Blue Jay					- Giant Osprey						- Giant Leopard Gecko				- Giant Beetle
- Giant Cardinal					- Giant Emu							- Giant Desert Tortoise				- Giant Monarch Butterfly
- Giant Grackle						- Giant Cockateel					- Giant Gila Monster				- Giant Firefly
- Giant Oriole						- Giant Peach-faced Love Bird		- Mule / Donkey / Horse				- Giant Dragonfly
- Giant Red-Winged Blackbird		- Giant Magpie						- Water Buffalo / Reindeer			- Hippo / Giant Hippo
- Giant Penguin						- Giant Kestrel						- Yak / Llama / Cow					- Giant Platypus
- Giant Peregrine Falcon			- Giant Albatross					- Giant Mountain Goat				- Giant Elephant
- Giant Kiwi						- Giant Great Horned Owl			- Giant Hoary Marmot				- Giant Warthog
- Ostrich / Giant Ostrich			- Giant Eagle						- Giant Grizzly Bear				- Giant Lion
- Giant Crow						- Giant Hornbill					- Black Bear / Giant Black Bear		- Giant Leopard
- Giant Raven						- Giant Masked Lovebird				- Deer / Giant Deer					- Giant Jaguar
- Giant Cassowary					- Giant Bushtit						- Giant Fox							- Giant Tiger
- Giant Kea							- Giant Damselfly					- Giant Raccoon						- Giant Cheetah
- Giant Snowy Owl					- Giant Moth						- Giant Rhesus Macaque				- Giant Gazelle
- Giant Sparrow						- Giant Grasshopper					- Cougar / Giant Cougar				- Giant Mandrill
- Giant White Stork					- Giant Bark Scorpion				- Wolf / Giant Wolf					- Gorilla / ALL Camels
- Giant Loon						- Giant Mantis						- Giant Groundhog					- Saltwater Crocodile
- Giant Barn Owl					- Giant Tick						- Alligator / Giant Alligator		- Giant Saltwater Crocodile
- Giant Parakeet					- Giant Louse						- Giant Buzzard						- Giant Vulture
- Giant Kakapo						- Giant Thrips						- Panda / Giant Capybara			- Rhinoceros / Giant Rhinoceros
- Giant Grey Parrot					- Giant Slug						- Badger / Giant Badger				- Giraffe / Giant Giraffe
- Giant Puffin						- Giant Jumping Spider				- Moose / Giant Moose				- Honey Badger / Giant Honey Badger
- Giant Swan						- Giant Moon Snail					- Giant Red Panda					- Giant Tortoise
- Giant Lorikeet					- Giant Brown Recluse Spider		- Giant Fly							- Gigantic Tortoise
- Giant	Armmadillo					- Muskox / Giant Muskox				- Elk / Giant Elk					- Giant Polar Bear
- Wolverine / Giant Wolverine		- Giant Chinchilla					- Voracious Cave Crawler			- Elk Bird
- Rutherer							- Draltha							- Blind Cave Bear					- Cave Dragon
- Giant Walrus						- Giant Narwhal						- Giant Octopus						- Giant Crab
- Giant Leopard Seal				- Giant Cuttlefish					- Giant Orca						- Giant Sponge
- Giant Horseshoe Crab				- Giant Sperm Whale					- Giant Elephant Seal				- Giant Harp Seal
- Giant Nautilus					- Giant Lizard						- Giant Skink						- Giant Chameleon
- Giant Anole						- Giant Iguana						- Giant Otter						- Giant Snapping Turtle
- Giant Beaver						- Giant Leech						- Giant Axolotl						- Giant Mink
- Giant Pond Turtle					- Giant Hamster						- Giant Hedgehog					- Giant Flying Squirrel
- Giant Gray / Red Squirrel			- Giant Chipmunk					- Gigantic Squid					- Unicorn
- Ice Wolf							- Hydra								- Sea Serpent						- Cave Crocodile
- Giant Cave Toad					- Giant Olm							- Giant Bat							- Giant Rat
- Giant Mole						- Giant Cave Spider					- Giant Cave Swallow				- Giant Wild Boar
- Coytoe / Giant Coyote				- Giant Kangaroo					- Giant Koala						- Giant Adder
- Giant Echidna						- Giant Kingsnake					- Giant Grey Langur					- Giant Bobcat
- Giant Skunk						- Giant Green Tree Frog				- Giant Hare						- Giant Rattlesnake
- Giant Weasel						- Giant Copperhead Snake			- Giant Ibex						- Giant Wombat
- Dingo / Giant Dingo				- Giant Coati						- Giant Opossum						- Mongoose / Giant Mongoose
- Hyena / Giant Hyena				- Giant Anaconda					- Giant Monitor Lizard				- Giant King Cobra
- Giant Ocelot						- Jackal / Giant Jackal				- Giant Capuchin					- Giant Sloth
- Giant Spider Monkey				- Giant Pangolin					- Giant Black Mamba					- Giant Sloth Bear
- Giant Aye-Aye						- Giant Bushmaster					- Giant Python						- Giant Tapir
- Giant Impala						- Giant Aardvark					- Giant Lion Tamarin				- Giant Stoat
- Giant Lynx						- Beak Dog							- Giant Porcupine

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{RIDE}
=======

\hack\scripts

First, you need to get the dwarf you want as the rider, and the creature you want as the mount together in the same tile.
Then, activate the script in the DFHack console with the cursor over the tile. Next, go into the animals "z" menu screen
and hit "enter" to confirm. It helps if they're war-trained. To dismount and terminate the "connection" between rider and
mount, all you need to do is Pasture/Pen the creature. Realistically, there is nothing preventing you from mounting a dwarf
to a cat, or a gorlak to an owl, or a dwarf to a dwarf to a bear to a jabberer to a roc, but doing so may have unexpected 
effects. This script should, in theory also enable attackers to carry their riders off-map to siege, either counted both
as rider-mount, or seperately. They should also appear in sieges. I may potentially increasing the aggression for the
particular animals chosen for mounts by tweaking the raws in the future. If you'd like to make animals available for hunting
or war, all you need to do is add the [TRAINABLE_HUNTING], [TRAINABLE_WAR], or [TRAINABLE] tokens to the respective creatures,
or the [MOUNT] or [MOUNT_EXOTIC] token for Adventure Mode. Doing so will also, coincidentally, work on an existing savefile.
					 
Please ride responsibly, have fun, and make sure to thank Warmist, Fanfloosh, and Rumrusher for their work on the script.

=======
{BIOM}
=======

\hack\scripts

Documentation & Usage: http://www.bay12forums.com/smf/index.php?topic=164658.0

=======
{REGN}
=======

\hack\scripts

Documentation & Usage: http://www.bay12forums.com/smf/index.php?topic=164136.0

=======
{LIBR}
=======

\hack\scripts

Documentation & Usage: http://www.bay12forums.com/smf/index.php?topic=170462.0

=======
{WAVE}
=======

onMapLoad_PeridexisErrant.init
\hack\scripts

Documentation & Usage: https://dwarffortresswiki.org/index.php/User:Fleeting_Frames/max-wave

For clarification, you can and should modify this according to your personal preferences. Or you can just delete the script
if you don't intend on using it. Add the following to the end of your onMapLoad_PeridexisErrant.init file, minus the quotation marks.

"# This should fix migrant waves to 10 each, upto a max population
# of 200 dwarves.
repeat -time 1 -timeUnits months -command [ max-wave 10 200 ]"

You should replace the "10" and "200" in both the onMapLoad_PeridexisErrant.init and the max-wave.lua scripts with whatever you wish to set your
maximum migrant wave number at, and whatever your maximum population is according to the LNP. Don't worry, it's easy to do! The first number is your
"migrant wave," and the second number is your "max population."

You can find the onMapLoad_PeridexisErrant.init file in your Dwarf Fortress folder, and the max-wave script in your "\hack\scripts" folder.

If you have no need of this script, feel free to delete it. My mod does not rely on it.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{CACA}
=======

descriptor_shape_standard_LA.txt

[OBJECT:DESCRIPTOR_SHAPE]

[SHAPE:ELFKING_LA]
   [NAME:Elf King Cacame Awemedinade:Elf King Cacame Awemedinade]
   [ADJ:awe-inspiring]
   [ADJ:grand]
   [ADJ:marvelous]
   [ADJ:kickass]
   [ADJ:Elf-hating]
   [ADJ:ale-chugging]
   [ADJ:rum-swilling]
   [ADJ:great]
   [ADJ:excellent]
   [ADJ:fantastic]
   [ADJ:majestic]
   [ADJ:extraordinary]
   [ADJ:tall]
   [ADJ:legendary]
   [ADJ:handsome]
   [ADJ:manly]
   [ADJ:hammer-swinging]
   [ADJ:hard-boiled]
   [ADJ:Human-hewing]
   [ADJ:horse-punting]
   [ADJ:magma-loving]
   [ADJ:hammering]
   [ADJ:fighting]
   [ADJ:warring]
   [ADJ:Goblin-killing]
   [ADJ:zombie wyvern-riding]
   [ADJ:dragon-slaying]
   [ADJ:hardballing]
   [ADJ:demon-slaying]
   [ADJ:siege-breaking]
   [ADJ:adventuring]
   [TILE:69]
   
As a bit of a lark, I've fished out a raw edit that allows everyone's favorite Elf-King to appear in other worlds as decorations and
engravings. Very rarely, he may even wind up in a list of what a particular dwarf likes. I've added a couple [ADJ] tokens to include the
fact that he punted a horse, and a few other tidbits. [TILE:69] should be the "E" tile, however it might be a bit wonky depending on what
tileset is currently installed. If so, try changing the tile number to whatever the respective tile for Elf is in that tileset. All credit goes
to Shima from the Dwarf Fortress Wiki for this one.

If you're not a fan, feel free to delete the descriptor_shape_standard_LA.txt file. No muss, no fuss!

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{RBIN}
=======

reaction_custom_LA.txt

[OBJECT:REACTION]

[REACTION:MAKE_ROCK_BIN_LA]
	[NAME:Make Rock Bin]
	[ADVENTURE_MODE_ENABLED]
	[BUILDING:CRAFTSMAN:CUSTOM_SHIFT_N]
	[REAGENT:A:1:BOULDER:NO_SUBTYPE:INORGANIC:NONE]
		[WORTHLESS_STONE_ONLY]
	[PRODUCT:100:1:BIN:NONE:GET_MATERIAL_FROM_REAGENT:A:NONE]
		[PRODUCT_TOKEN:bin]
	[SKILL:STONECRAFT]
	[CATEGORY_DESCRIPTION:Finally, something else to do with all that bloody stone laying around!]
	
A relatively simple reaction, but fairly useful. Make a rock bin from the Craftsdwarf's Workshop out of some of that stone cluttering up your halls.
The reaction requires one boulder.  If this looks strange with a graphical tileset installed, please let me know and I will look into a custom tileset
for the new reactions and items.

=======
{RBED}
=======

reaction_custom_LA.txt

[OBJECT:REACTION]

[REACTION:MAKE_ROCK_BED_LA]
	[NAME:Make Rock Bed]
	[ADVENTURE_MODE_ENABLED]
	[BUILDING:MASON:CUSTOM_SHIFT_B]
	[REAGENT:A:2:BOULDER:NO_SUBTYPE:INORGANIC:NONE]
		[WORTHLESS_STONE_ONLY]
	[REAGENT:B:1:TANNED_HIDE:NO_SUBTYPE:NONE:NONE]
	[PRODUCT:100:1:BIN:NONE:GET_MATERIAL_FROM_REAGENT:A:NONE]
		[PRODUCT_TOKEN:bed]
	[SKILL:MASONRY]
	[CATEGORY_DESCRIPTION:A wondrous stone bed, fit for a dwarf. Requires leather for pillow and blankets. Mmmmm...comfy.]

Another simple reaction designed to provide another useful way to remove stone. Make a rock bed from two boulders and some leather.
Again, I'm not sure if this will look weird with a graphical tileset, so please let me know if that is the case.

=======
{VBRN}
=======

reaction_custom_LA.txt

[OBJECT:REACTION]

[REACTION:BURN_VERMIN_REMAINS_LA]
	[NAME:Burn Vermin Remains]
	[ADVENTURE_MODE_ENABLED]
	[BUILDING:WOOD:CUSTOM_SHIFT_V]
	[REAGENT:A:5:REMAINS:NONE:NONE:NONE]
	[PRODUCT:25:1:BAR:NONE:POTASH:NONE][PRODUCT_DIMENSION:150]
	[SKILL:WOOD_BURNER]
	[AUTOMATIC]
	[CATEGORY_DESCRIPTION:Automatically dispose of vermin remains, with a small chance to get a potash bar.]
	
My personal favorite out of the reactions I've created so far. The reaction is [AUTOMATIC],and enabled from the Wood Furnace. What this does is
take 5 vermin remains and cremate them, with a 25% chance of producing a Potash bar as a result. Feel free to ignore the reaction if you feel it's
"cheaty." I figure it may help with FPS decay over time by keeping those corpses to a minimum, provide something else productive for a woodburner to
do, help keep the fortress "sanitary" from an RP perspective, and provide newer players or those without the means to get a bit of fertilizer.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WS01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_BASTARD_LA]
[NAME:bastard sword:bastard swords] Who's the bastard that decided dwarves couldn't use two-handed swords? Lemme at 'im!
[SIZE:1100]
[SKILL:SWORD]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[CAN_STONE]
[MATERIAL_SIZE:5]
[ATTACK:EDGE:20500:4250:slash:slashes:blade:1250]
    [ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:EDGE:25:6000:stab:stabs:tip:1250]
    [ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:BLUNT:20500:4250:slap:slaps:flat:1250:
    [ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:60:600:strike:strikes:pommel:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:2]

=======
{WS02}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_RAPIER_LA] I'm hoping the multi-attack flag will allow dual-wielding with the Main-Gauche.
[NAME:rapier:rapiers] Naturally, you must expect me to attack with Capo-Ferro!
[SIZE:625]
[SKILL:SWORD]
[TWO_HANDED:35000]
[MINIMUM_SIZE:32500]
[MATERIAL_SIZE:4]
[ATTACK:EDGE:6250:1000:slash:slashes:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:EDGE:10:3750:stab:stabs:tip:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:3]	
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:EDGE:10:3750:thrust:thrusts:tip:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:3]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:BLUNT:6250:100:slap:slaps:flat:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:BLUNT:45:450:strike:strikes:pommel:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

=======
{WS03}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

[ITEM_WEAPON:ITEM_WEAPON_SWORD_FLAMBERGE_LA] Hoping for the same result as with the Rapier.
[NAME:flamberge:flamberges] Naturally, but I find that Thibault cancels Capo-Ferro, don't you?
[SIZE:675]
[SKILL:SWORD]
[TWO_HANDED:35000]
[MINIMUM_SIZE:32500]
[MATERIAL_SIZE:4]
[ATTACK:EDGE:6750:1000:slash:slashes:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:EDGE:12:3750:stab:stabs:tip:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:3]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:EDGE:12:3750:thrust:thrusts:tip:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:3]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:BLUNT:6750:100:slap:slaps:flat:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:BLUNT:45:450:strike:strikes:pommel:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
	
=======
{WS04}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_ESTOC_LA] Again, hoping for same result as the Rapier and Flamberge.
[NAME:estoc:estocs] Unless the enemy hasn't studied his Agrippa, which I have!
[SIZE:725]
[SKILL:SWORD]
[TWO_HANDED:52500]
[MINIMUM_SIZE:37500]
[MATERIAL_SIZE:4]
[ATTACK:EDGE:7000:1000:slash:slashes:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:EDGE:15:4000:stab:stabs:tip:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:3]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:EDGE:15:4000:thrust:thrusts:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:3]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:BLUNT:7000:100:slap:slaps:flat:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:50:500:strike:strikes:pommel:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

=======
{WS05}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_KAMPILAN_LA]
[NAME:kampilan:kampilans] A straight, tapered blade, widening to the tip with a protruding spikelet. The pommel is distinct from culture to culture.
[SIZE:850]
[SKILL:SWORD]
[TWO_HANDED:50000]
[MINIMUM_SIZE:37500]
[MATERIAL_SIZE:6]
[CAN_STONE]
[ATTACK:EDGE:20000:4000:chop:chops:blade:1350]
	[ATTACK_PREPARE_AND_RECOVER:3:4]
[ATTACK:EDGE:20:5000:stab:stabs:double-tip:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:15000:3500:slap:slaps:flat:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:50:500:strike:strikes:pommel:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

=======
{WS06}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_BACKSWORD_LA]
[NAME:backsword:backswords] A single-edged blade with a triangular cross-section. Similar to a cutlass, but far less curved.
[SIZE:800]
[SKILL:SWORD]
[TWO_HANDED:37500]
[MINIMUM_SIZE:32500]
[MATERIAL_SIZE:5]
[CAN_STONE]
[ATTACK:EDGE:18000:3500:slash:slashes:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:17500:3250:strike:strikes:spine:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:17500:3250:slap:slaps:flat:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:50:500:strike:strikes:pommel:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

=======
{WS07}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_NIMCHA_LA]
[NAME:nimcha:nimchas] A unique type of scimitar. It a hilt with forward-pointing quillions, a "hooked" pommel, and a knuckle-guard.
[SIZE:825]
[SKILL:SWORD]
[TWO_HANDED:37500]
[MINIMUM_SIZE:32500]
[MATERIAL_SIZE:5]
[CAN_STONE]
[ATTACK:EDGE:17500:3750:slash:slashes:NO_SUB:1275]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:EDGE:20:4500:stab:stabs:clipped point:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:17000:3500:slap:slaps:flat:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:50:500:strike:strikes:pommel:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

=======
{WS08}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_SHOTEL_LA] A very long, very curved sword. Think "sickle-sword" and you've got the idea.
[NAME:shotel:shotels]
[SIZE:775]
[SKILL:SWORD]
[TWO_HANDED:47500]
[MINIMUM_SIZE:37500]
[MATERIAL_SIZE:5]
[CAN_STONE]
[ATTACK:EDGE:19000:3000:slash:slashes:curved blade:1275]
	[ATTACK_PREPARE_AND_RECOVER:3:4]
[ATTACK:EDGE:15000:3000:slash:slashes:curved spine:1275]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:12500:1000:slap:slaps:flat:1000]
	[ATTACK_PREPARE_AND_RECOVER:3:4]
[ATTACK:BLUNT:50:500:strike:strikes:pommel:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
	
=======
{WS09}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_OKAB_TARMID_LA]
[NAME:okab-tarmid:okab-tarmids] A ridiculously massive broadsword. Once wielded by a blonde, spiky-haired dwarf, fond of arrogance.
[SIZE:2250]
[SKILL:SWORD]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[MATERIAL_SIZE:30]
[CAN_STONE]
[ATTACK:EDGE:125000:9999:attack:attacks:blade:1500]
	[ATTACK_PREPARE_AND_RECOVER:3:4]
[ATTACK:EDGE:125000:9999:cross-slash:cross-slashes:blade:1500]
	[ATTACK_PREPARE_AND_RECOVER:3:4]
[ATTACK:BLUNT:125000:9999:impact:impacts:flat:1500]
	[ATTACK_PREPARE_AND_RECOVER:3:4]

=======
{WS10}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_UNAL_DASTOT_LA]
[NAME:unal-dastot:unal-dastots] A strange, blunt broadsword, with runic carvings near the hilt and a non-existent guard.
[SIZE:1500]
[SKILL:SWORD]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[MATERIAL_SIZE:15]
[CAN_STONE]
[ATTACK:EDGE:115000:9999:attack:attacks:hard-edge:1500]
	[ATTACK_PREPARE_AND_RECOVER:3:4]
[ATTACK:EDGE:115000:9999:cross-slash:cross-slashes:hard-edge:1500]
	[ATTACK_PREPARE_AND_RECOVER:3:4]
[ATTACK:BLUNT:115000:9999:impact:impacts:flat:1500]
	[ATTACK_PREPARE_AND_RECOVER:3:4]	

=======
{WS11}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SWORD_LONG_HAFTED_BLADE_LA]
[NAME:long-hafted blade:long-hafted blades] A larger variant of the Bhuj, with a short-sword affixed to a long, heavy, axe-haft. Originaly forged by a smith named Asin.
[SIZE:525]
[SKILL:SWORD]
[TWO_HANDED:32500]
[MINIMUM_SIZE:12500]
[CAN_STONE]
[MATERIAL_SIZE:4]
[ATTACK:EDGE:15000:5000:chop:chops:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:EDGE:15:10000:stab:stabs:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:1000:550:strike:strikes:haft:2500]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WD01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_DAGGER_WAVEBACK_SEAX_LA]
[NAME:waveback seax:waveback seaxes] The forsaken, bastard offspring of a seax and a kris.
[SIZE:450]
[SKILL:DAGGER]
[TWO_HANDED:30000]
[MINIMUM_SIZE:10000]
[CAN_STONE]
[MATERIAL_SIZE:3]
[ATTACK:EDGE:775:1250:slash:slashes:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:3]
[ATTACK:EDGE:800:1275:slash:slashes:spine:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:3]
[ATTACK:EDGE:15:3000:stab:stabs:tip:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
[ATTACK:BLUNT:30:600:strike:strikes:hilt:1000]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
	
=======
{WD02}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_DAGGER_MAIN_GAUCHE_LA] Designed to be used with the Estoc, Flamberge, or Rapier.
[NAME:main-gauche:main-gauches] Complete with knuckleguard, notched spine for parrying, and ornate quillions. En-guarde!
[SIZE:250]
[SKILL:DAGGER]
[TWO_HANDED:30000]
[MINIMUM_SIZE:10000]
[MATERIAL_SIZE:2]
[CAN_STONE]
[ATTACK:EDGE:725:1125:slash:slashes:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
[ATTACK:EDGE:10:2750:stab:stabs:point:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:EDGE:10:2750:thrust:thrusts:point:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:BLUNT:30:600:strike:strikes:pommel:1000]
	[ATTACK_PREPARE_AND_RECOVER:2:2]

=======
{WD03}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_DAGGER_STILETTO_LA]
[NAME:stiletto:stilettos] Small, pointy, and very good for stabbing. Often seen as an off-hand weapon, it is easy to conceal, sometimes even within another weapon.
[SIZE:175]
[SKILL:DAGGER]
[TWO_HANDED:10000]
[MINIMUM_SIZE:2500]
[CAN_STONE]
[MATERIAL_SIZE:2]
[ATTACK:EDGE:3:3000:stab:stabs:NO_SUB:1225]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:EDGE:3:3000:thrust:thrusts:NO_SUB:1225]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:BLUNT:30:300:strike:strikes:pommel:1000]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
	
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WA01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_AXE_GOOSEWING_GREAT_LA]
[NAME:goosewing great-axe:goosewing great-axes] This weapon menaces with spikes of norse-influence.
[SIZE:1325]
[SKILL:AXE]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[CAN_STONE]
[MATERIAL_SIZE:6]
[ATTACK:EDGE:60000:8000:chop:chops:blade:1350]
    [ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:60000:8000:slap:slaps:flat:1250]
    [ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:2000:250:strike:strikes:haft:3500]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:100:1000:strike:strikes:pommel:1250]
    [ATTACK_PREPARE_AND_RECOVER:3:3]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WE01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SPEAR_HEWING_LA]
[NAME:hewing-spear:hewing-spears] My mother told me, someday I would buy, galley with good oars, sail distant shores.
[SIZE:1000]
[SKILL:SPEAR]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[CAN_STONE]
[MATERIAL_SIZE:4]
[ATTACK:EDGE:50:9000:stab:stabs:tip:2000]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
[ATTACK:EDGE:250:2000:slash:slashes:edge:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:BLUNT:2000:250:strike:strikes:haft:3500]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
	
=======
{WE02}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_SPEAR_BHUJ_LA]
[NAME:bhuj:bhuji] A short, recurve knife, affixed to an axe-haft. They are often very ornate, with the knob almost invariably designed as a stylized elephants head.
[SIZE:450]
[SKILL:SPEAR]
[TWO_HANDED:30000]
[MINIMUM_SIZE:7500]
[CAN_STONE]
[MATERIAL_SIZE:4]
[ATTACK:EDGE:500:1350:slash:slashes:blade:1350]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:EDGE:175:1275:slash:slashes:rear-edge:1275]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:EDGE:10:7500:stab:stabs:tip:1275]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:BLUNT:1000:500:strike:strikes:haft:2275]
	[ATTACK_PREPARE_AND_RECOVER:3:2]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WP01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_HALBERD_BEARDED_LA]
[NAME:halberd:halberds] By Urist, they've done it! A mighty halberd, fit for a dwarf!
[SIZE:1275]
[SKILL:PIKE]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[CAN_STONE]
[ADJECTIVE:bearded]
[MATERIAL_SIZE:6]
[ATTACK:EDGE:22500:3500:hack:hacks:blade:2000]
	[ATTACK_PREPARE_AND_RECOVER:4:3]
[ATTACK:EDGE:50:1350:stab:stabs:spike:1350]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:EDGE:30:1250:hook:hooks:thorn:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:BLUNT:2000:250:strike:strikes:haft:3500]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:20000:2000:slap:slaps:flat:1750]
	[ATTACK_PREPARE_AND_RECOVER:4:3]
	
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WH01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_MAUL_DWARVEN_LA]
[NAME:maul:mauls] A marvelous maul, with which to mash malevolent mooks.
[SIZE:1600]
[SKILL:HAMMER]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[CAN_STONE]
[ADJECTIVE:dwarven]
[MATERIAL_SIZE:8]
[ATTACK:BLUNT:50:3500:hammer:hammers:striking face:4000]
	[ATTACK_PREPARE_AND_RECOVER:4:5]
	[ATTACK_FLAG_BAD_MULTIATTACK]
[ATTACK:BLUNT:75:3500:bash:bashes:head:2000]
	[ATTACK_PREPARE_AND_RECOVER:4:4]
[ATTACK:BLUNT:2000:250:strike:strikes:haft:3500]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
	
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WM01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_MACE_ORGALS_PAW_LA]
[NAME:Orgal's Paw:Orgal's Paws] Essentialy a Chinese Zhua in the shape of a bear's paw. Used for rending armor and ripping shields. Hail Orgal Shorodeht!
[SIZE:1500]
[SKILL:MACE]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[CAN_STONE]
[MATERIAL_SIZE:7]
[ATTACK:BLUNT:1000:6000:rend:rends:paw:3500]
	[ATTACK_PREPARE_AND_RECOVER:4:4]
[ATTACK:EDGE:10:6000:tear:tears:claws:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:4]
[ATTACK:BLUNT:2000:250:strike:strikes:haft:3500]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WW01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_WHIP_DRAGON_TAIL_LA]
[NAME:whip:whips] A serrated whip, emulating the tail of a dragon. Beware it's wrath!
[SIZE:450]
[SKILL:WHIP]
[ADJECTIVE:dragon tail]
[TWO_HANDED:30000]
[MINIMUM_SIZE:10000]
[MATERIAL_SIZE:3]
[ATTACK:BLUNT:5:25:lash:lashes:serrated tips:5250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
	[ATTACK_FLAG_BAD_MULTIATTACK]
[ATTACK:EDGE:150:75:bite:bites:serrated edges:3750]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
	[ATTACK_FLAG_BAD_MULTIATTACK]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WT01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_HALBERD_TRAINING_LA]
[NAME:training halberd:training halberd]
[SIZE:635]
[SKILL:PIKE]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[MATERIAL_SIZE:4]
[ATTACK:EDGE:22500:3500:hack:hacks:blade:2000]
	[ATTACK_PREPARE_AND_RECOVER:4:3]
[ATTACK:EDGE:50:1350:poke:pokes:spike:1350]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:EDGE:30:1250:hook:hooks:thorn:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:2]
[ATTACK:BLUNT:2000:250:strike:strikes:haft:3500]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[ATTACK:BLUNT:20000:2000:slap:slaps:flat:1750]
	[ATTACK_PREPARE_AND_RECOVER:4:3]
[TRAINING]

=======
{WT02}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_MACE_TRAINING_PAW_LA]
[NAME:training paw:training paws]
[SIZE:750]
[SKILL:MACE]
[TWO_HANDED:77500]
[MINIMUM_SIZE:52500]
[MATERIAL_SIZE:4]
[ATTACK:BLUNT:1000:6000:bat:bats:paw:3500]
	[ATTACK_PREPARE_AND_RECOVER:4:4]
[ATTACK:EDGE:10:6000:pull:pulls:claws:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:4]
[ATTACK:BLUNT:2000:250:strike:strikes:haft:3500]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
[TRAINING]

=======
{WT03}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_WHIP_TRAINING_LA]
[NAME:training whip:training whips]
[SIZE:225]
[SKILL:WHIP]
[TWO_HANDED:30000]
[MINIMUM_SIZE:10000]
[MATERIAL_SIZE:2]
[ATTACK:BLUNT:5:25:lash:lashes:tip:5250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
	[ATTACK_FLAG_BAD_MULTIATTACK]
[ATTACK:EDGE:150:75:bite:bites:cord:3750]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
	[ATTACK_FLAG_BAD_MULTIATTACK]
[TRAINING]

=======
{WT04}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_DAGGER_TRAINING_LA]
[NAME:training dagger:training daggers]
[SIZE:250]
[SKILL:DAGGER]
[TWO_HANDED:30000]
[MINIMUM_SIZE:10000]
[MATERIAL_SIZE:2]
[ATTACK:EDGE:725:1125:slash:slashes:blade:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
[ATTACK:EDGE:10:2750:poke:pokes:point:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:EDGE:10:2750:jab:jabs:point:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
	[ATTACK_FLAG_INDEPENDENT_MULTIATTACK]
[ATTACK:BLUNT:30:600:strike:strikes:pommel:1000]
	[ATTACK_PREPARE_AND_RECOVER:2:2]
[TRAINING]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WR01}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_BOW_RECURVE_SIEGE_LA]
[NAME:recurve siege-bow:recurve siege-bows] About the size of a dwarf, and requiring the strength of one for a full draw.
[SIZE:600]
[SKILL:MISC_WEAPON]
[RANGED:BOW:ARROW]
[SHOOT_FORCE:2000]
[SHOOT_MAXVEL:400]
[TWO_HANDED:0]
[MINIMUM_SIZE:30000]
[MATERIAL_SIZE:3]
[ATTACK:BLUNT:3000:4000:bash:bashes:NO_SUB:1150]
	[ATTACK_PREPARE_AND_RECOVER:3:3]
	
=======
{WR02}
=======

item_weapon_LA.txt

[OBJECT:ITEM]

	[ITEM_WEAPON:ITEM_WEAPON_CROSSBOW_BAYONETTED_LA]
[NAME:crossbow:crossbows] A bulkier crossbow, fitted with a bayonet. Now with fifty percent more than twenty pecent more Urists of velocity!
[ADJECTIVE:bayonetted]
[SIZE:800]
[SKILL:SPEAR]
[RANGED:CROSSBOW:BOLT]
[SHOOT_FORCE:2250]
[SHOOT_MAXVEL:500]
[TWO_HANDED:0]
[MINIMUM_SIZE:35000]
[MATERIAL_SIZE:4]
[ATTACK:EDGE:100:500:stab:stabs:bayonet:1250]
	[ATTACK_PREPARE_AND_RECOVER:2:3]
[ATTACK:BLUNT:8000:4250:bash:bashes:stock:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{WO01}
=======

item_ammo_LA.txt

[OBJECT:ITEM]
	
	[ITEM_AMMO:ITEM_AMMO_ARROWS_BODKIN_LA]
[NAME:bodkin arrow:bodkin arrows] A heavier arrow with a hardened, squared tip. Meant for piercing mail and armor.
[CLASS:ARROW]
[SIZE:195]
[ATTACK:EDGE:2:9000:impact:impacts:NO_SUB:1150]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

=======
{WO02}
=======

item_ammo_LA.txt

[OBJECT:ITEM]

	[ITEM_AMMO:ITEM_AMMO_QUARREL_BROADHEAD_LA]
[NAME:broadhead quarrel:broadhead quarrels] A heavy, broad-headed quarrel for use with crossbows. A quarrel is a bolt, not a bunch of them. ;)
[CLASS:BOLT]
[SIZE:215]
[ATTACK:EDGE:7:10000:impact:impacts:NO_SUB:1250]
	[ATTACK_PREPARE_AND_RECOVER:3:3]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{AC01}
=======

item_armor_LA.txt

[OBJECT:ITEM]

	[ITEM_ARMOR:ITEM_ARMOR_GAMBESON_LA]
[NAME:gambeson:gambesons] A very effective, and often overlooked piece of armor. Really just a thick, padded, cloth or leather coat.
[ADJECTIVE:thick]
[MATERIAL_PLACEHOLDER:leather]
[ARMORLEVEL:1]
[UBSTEP:MAX]
[LBSTEP:1]
[LAYER:UNDER]
[COVERAGE:110]
[LAYER_SIZE:15]
[LAYER_PERMIT:50]
[MATERIAL_SIZE:4]
[SOFT]
[LEATHER]
[STRUCTURAL_ELASTICITY_WOVEN_THREAD]

=======
{AC02}
=======

item_armor_LA.txt

[OBJECT:ITEM]

	[ITEM_ARMOR:ITEM_ARMOR_GAMBESON_CLOTH_LA]
[NAME:gambeson:gambesons] A very effective, and often overlooked piece of armor. Really just a thick, padded, cloth or leather coat.
[ADJECTIVE:quilted]
[ARMORLEVEL:0]
[UBSTEP:MAX]
[LBSTEP:1]
[LAYER:UNDER]
[COVERAGE:110]
[LAYER_SIZE:10]
[LAYER_PERMIT:50]
[MATERIAL_SIZE:4]
[SOFT]
[STRUCTURAL_ELASTICITY_WOVEN_THREAD]

=======
{AC03}
=======

item_armor_LA.txt

[OBJECT:ITEM]

	[ITEM_ARMOR:ITEM_ARMOR_BRIGANDINE_LA]
[NAME:brigandine:brigandines] Brigantine? No. Brigandine! Metal plates, riveted to heavy fabric or leather. Worn as armor, or as an under-layer to full-plate.
[ARMORLEVEL:2]
[UBSTEP:MAX]
[LBSTEP:1]
[LAYER:ARMOR]
[COVERAGE:110]
[LAYER_SIZE:20]
[LAYER_PERMIT:50]
[MATERIAL_SIZE:5]
[METAL]
[BARRED]
[SCALED]

=======
{AC04}
=======

item_armor_LA.txt

[OBJECT:ITEM]

	[ITEM_ARMOR:ITEM_ARMOR_MAIL_HAUBERK_LA]
[NAME:mail hauberk:mail hauberks] Designed to be worn under the brigandine, but over the gambeson, the hauberk provides more protection than a common mail shirt.
[CHAIN_METAL_TEXT]
[ARMORLEVEL:2]
[UBSTEP:1]
[LBSTEP:2]
[LAYER:OVER]
[COVERAGE:110]
[LAYER_SIZE:15]
[LAYER_PERMIT:50]
[MATERIAL_SIZE:6]
[HARD]
[METAL]
[STRUCTURAL_ELASTICITY_CHAIN_ALL]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{AS01}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_TARGE_LA] Slightly bigger, and thus, only slightly better than a buckler.
[NAME:targe:targes]
[ARMORLEVEL:1]
[BLOCKCHANCE:15]
[UPSTEP:1]
[MATERIAL_SIZE:3]

=======
{AS02}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_TARGET_LA] Great, just what the goblin marksmen needed; another target. Similar to a buckler but rectangular.
[NAME:target shield:target shields]
[ARMORLEVEL:1]
[BLOCKCHANCE:18]
[UPSTEP:1]
[MATERIAL_SIZE:3]

=======
{AS03}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_ASPIS_LA] A deeply dished, convex round-shield with its grip more towards the edge.
[NAME:aspis:aspides]
[ARMORLEVEL:2]
[BLOCKCHANCE:20]
[UPSTEP:2]
[MATERIAL_SIZE:3]

=======
{AS04}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_SCUTUM_LA] Get yer mind outta the gutter! A rectangular, rounded shield with a spindle-shaped boss on the front.
[NAME:scutum:scutamae]
[ARMORLEVEL:2]
[BLOCKCHANCE:30]
[UPSTEP:2]
[MATERIAL_SIZE:4]

=======
{AS05}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_WANKEL_LA] A triangular shield, similar to a kite-shield but smaller, and with rounded edges.
[NAME:wankel shield:wankel shields]
[ARMORLEVEL:3]
[BLOCKCHANCE:22]
[UPSTEP:3]
[MATERIAL_SIZE:3]

=======
{AS06}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_SQUARE_LA] A square shield to go with your pixels good sir!
[NAME:square shield:square shields]
[ARMORLEVEL:3]
[BLOCKCHANCE:28]
[UPSTEP:3]
[MATERIAL_SIZE:4]

=======
{AS07}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_HEATER_LA] By Armok! No matter how we try, we can't warm our dwarven toes with it!
[NAME:heater shield:heater shields]
[ARMORLEVEL:3]
[BLOCKCHANCE:33]
[UPSTEP:4]
[MATERIAL_SIZE:5]

=======
{AS08}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_KITE_LA] You could attach it to a string, but it's far too heavy to fly.
[NAME:kite shield:kite shields]
[ARMORLEVEL:3]
[BLOCKCHANCE:40]
[UPSTEP:4]
[MATERIAL_SIZE:6]

=======
{AS09}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_COFFIN_LA] As dwarven a shield as was ever forged. Often inscribed with runes and ancestral markings.
[NAME:coffin shield:coffin shields]
[ARMORLEVEL:3]
[BLOCKCHANCE:45]
[UPSTEP:5]
[MATERIAL_SIZE:7]

=======
{AS10}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_TEARDROP_LA] Don't you cryyyyyy tonight, there's a shield in front of you baby.
[NAME:teardrop shield:teardrop shields]
[ARMORLEVEL:3]
[BLOCKCHANCE:50]
[UPSTEP:5]
[MATERIAL_SIZE:8]

=======
{AS11}
=======

item_shield_LA.txt

[OBJECT:ITEM]

	[ITEM_SHIELD:ITEM_SHIELD_TOWER_LA] A massive great-shield. A dwarven squad displaying these in shield-wall formation is truly a sight to behold.
[NAME:tower shield:tower shields]
[ARMORLEVEL:3]
[BLOCKCHANCE:55]
[UPSTEP:6]
[MATERIAL_SIZE:9]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=======
{ENTT}
=======

All changes to these files are denote by *XxHyde840xX* appearing at the end.

entity_default.txr

[OBJECT:ENTITY]

	[WEAPON:ITEM_WEAPON_HALBERD_BEARDED_LA]
	[WEAPON:ITEM_WEAPON_MAUL_DWARVEN_LA]
	[WEAPON:ITEM_WEAPON_SPEAR_HEWING_LA]
	[WEAPON:ITEM_WEAPON_AXE_GOOSEWING_GREAT_LA]
	[WEAPON:ITEM_WEAPON_SWORD_BASTARD_LA]
	[WEAPON:ITEM_WEAPON_MACE_ORGALS_PAW_LA]
	[WEAPON:ITEM_WEAPON_WHIP_DRAGON_TAIL_LA]
	[WEAPON:ITEM_WEAPON_DAGGER_WAVEBACK_SEAX_LA]
	[WEAPON:ITEM_WEAPON_DAGGER_MAIN_GAUCHE_LA]
	[WEAPON:ITEM_WEAPON_SWORD_RAPIER_LA]
	[WEAPON:ITEM_WEAPON_SWORD_FLAMBERGE_LA]
	[WEAPON:ITEM_WEAPON_SWORD_ESTOC_LA]
	[WEAPON:ITEM_WEAPON_SWORD_KAMPILAN_LA]
	[WEAPON:ITEM_WEAPON_SWORD_BACKSWORD_LA]
	[WEAPON:ITEM_WEAPON_SWORD_NIMCHA_LA]
	[WEAPON:ITEM_WEAPON_SWORD_SHOTEL_LA]
	[WEAPON:ITEM_WEAPON_SWORD_OKAB_TARMID_LA]
	[WEAPON:ITEM_WEAPON_SWORD_UNAL_DASTOT_LA]
	[WEAPON:ITEM_WEAPON_SPEAR_BHUJ_LA]
	[WEAPON:ITEM_WEAPON_DAGGER_STILETTO_LA]
	[WEAPON:ITEM_WEAPON_SWORD_LONG_HAFTED_BLADE_LA]

	[WEAPON:ITEM_WEAPON_BOW_RECURVE_SIEGE_LA]
	[WEAPON:ITEM_WEAPON_CROSSBOW_BAYONETTED_LA]
	
		[AMMO:ITEM_AMMO_ARROWS_BODKIN_LA]
		[AMMO:ITEM_AMMO_QUARREL_BROADHEAD_LA]
	
	[WEAPON:ITEM_WEAPON_HALBERD_TRAINING_LA]
	[WEAPON:ITEM_WEAPON_MACE_TRAINING_PAW_LA]
	[WEAPON:ITEM_WEAPON_WHIP_TRAINING_LA]
	[WEAPON:ITEM_WEAPON_DAGGER_TRAINING_LA]
	
	[ARMOR:ITEM_ARMOR_GAMBESON_LA:FORCED]
	[ARMOR:ITEM_ARMOR_GAMBESON_CLOTH_LA:FORCED]
	[ARMOR:ITEM_ARMOR_BRIGANDINE_LA:FORCED]
	[ARMOR:ITEM_ARMOR_MAIL_HAUBERK_LA:FORCED]
	
	[SHIELD:ITEM_SHIELD_HEATER_LA]
	[SHIELD:ITEM_SHIELD_KITE_LA]
	[SHIELD:ITEM_SHIELD_COFFIN_LA]
	[SHIELD:ITEM_SHIELD_TOWER_LA]
	[SHIELD:ITEM_SHIELD_TARGE_LA]
	[SHIELD:ITEM_SHIELD_TARGET_LA]
	[SHIELD:ITEM_SHIELD_ASPIS_LA]
	[SHIELD:ITEM_SHIELD_SCUTUM_LA]
	[SHIELD:ITEM_SHIELD_WANKEL_LA]
	[SHIELD:ITEM_SHIELD_SQUARE_LA]
	[SHIELD:ITEM_SHIELD_TEARDROP_LA]
	
	[PERMITTED_REACTION:MAKE_ROCK_BIN_LA]
	[PERMITTED_REACTION:MAKE_ROCK_BED_LA]
	[PERMITTED_REACTION:BURN_VERMIN_REMAINS_LA]

===============================
		~	 FIN	 ~
===============================